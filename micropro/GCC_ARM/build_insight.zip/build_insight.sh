#!/bin/sh

TARGET=arm-none-eabi
PREFIX=~/GCC_ARM/insight 	 # Install location of your final toolchain
PARALLEL=""			 # Or: PARALLEL=""

INSIGHT=insight-6.8-1

export PATH="$PATH:$PREFIX/bin"

mkdir build

#wget -c ftp://sourceware.org/pub/insight/releases/$INSIGHT.tar.bz2
tar xfvj $INSIGHT.tar.bz2
cd build
../$INSIGHT/configure --target=$TARGET --prefix=$PREFIX \
         --with-gnu-as --with-gnu-ld \
         --enable-interwork --enable-multilib --disable-werror --with-float=soft
#make $PARALLEL
make all install

cd ..

#rm -rf build $INSIGHT $INSIGHT.tar.bz2

#sudo ln -s $PREFIX/bin/arm-elf* /usr/bin


